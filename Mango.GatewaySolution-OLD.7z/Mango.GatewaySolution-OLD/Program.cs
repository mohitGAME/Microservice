using GraphiQl;
using GraphQL;
using Mango.GatewaySolution.Extensions;
using Ocelot.DependencyInjection;
using Ocelot.Values;
using StarWars;

var builder = WebApplication.CreateBuilder(args);
builder.AddAppAuthetication();
if (builder.Environment.EnvironmentName.ToString().ToLower().Equals("production"))
{
    builder.Configuration.AddJsonFile("ocelot.Production.json", optional: false, reloadOnChange: true);
}
else
{
    builder.Configuration.AddJsonFile("ocelot.json", optional: false, reloadOnChange: true);
}
builder.Services.AddOcelot(builder.Configuration);
builder.Services.AddGraphQL(b => b
                .AddSchema<StarWarsSchema>()
                .AddSystemTextJson()
                .AddValidationRule<InputValidationRule>()
                .AddGraphTypes(typeof(StarWarsSchema).Assembly));
//.AddMemoryCache()
//.AddApolloTracing(options => options.RequestServices!.GetRequiredService<IOptions<GraphQLSettings>>().Value.EnableMetrics));
builder.Services.AddSingleton<StarWarsData>();


builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();
app.UseGraphiQl("/whatever/graphiql");
//app.MapGet("/", () => "Hello World!");
//app.MapEndpoints();
app.MapControllers();


//app.UseOcelot().GetAwaiter().GetResult();
app.Run();



//builder.Services.AddGraphQL(b => b
//                .AddSchema<StarWarsSchema>()
//                .AddSystemTextJson()
//                .AddValidationRule<InputValidationRule>()
//                .AddGraphTypes(typeof(StarWarsSchema).Assembly)
//                );