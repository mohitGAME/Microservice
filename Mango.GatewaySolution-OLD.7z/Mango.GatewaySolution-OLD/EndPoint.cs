﻿using GraphQL;
using GraphQL.SystemTextJson;
using GraphQL.Types;

namespace Mango.GatewaySolution
{
    public static class Endpoints
    {
        public static void MapEndpoints(this WebApplication app)
        {
            app.MapGet("/{input}", async (string input) =>
            {


                var schema = Schema.For(@"
                              type Query {
                                hello: String
                              }
                            ");

                var root = new { Hello = input };
                var json = await schema.ExecuteAsync(_ =>
                {
                    _.Query = "{ hello }";
                    _.Root = root;
                });

                return json;


            });

            app.MapGet("/greet/{name}", (string name) => $"Hello, {name}!");

            app.MapGet("/time", () => DateTime.Now.ToString("hh:mm:ss"));

        }
    }
}