﻿using GraphQL;
using GraphQL.Transport;
using GraphQL.Types;
using Microsoft.AspNetCore.Mvc;

namespace Mango.GatewaySolution
{
    [Route("[controller]")]
    [ApiController]

    public class GraphQlController : ControllerBase
    {
        private readonly IDocumentExecuter _documentExecuter;
        private readonly ISchema _schema;
        public GraphQlController(IDocumentExecuter documentExecuter, ISchema schema)
        {
            _documentExecuter = documentExecuter;
            _schema = schema;
        }

        [HttpPost]
        public async Task<IActionResult> GraphQLAsync([FromBody] GraphQLRequest request)
        {
            var startTime = DateTime.UtcNow;

            var result = await _documentExecuter.ExecuteAsync(s =>
            {
                s.Schema = _schema;
                s.Query = request.Query;
                s.Variables = request.Variables;
                s.OperationName = request.OperationName;
                s.RequestServices = HttpContext.RequestServices;
                //s.UserContext = new GraphQLUserContext
                //{
                //    User = HttpContext.User,
                //};
                s.CancellationToken = HttpContext.RequestAborted;
            });

            //if (_graphQLOptions.Value.EnableMetrics)
            //{
            //    result.EnrichWithApolloTracing(startTime);
            //}

            return Ok(result);
        }
    }


    //public class Product
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }
    //}

    //public class ProductReview
    //{
    //    public int Id { get; set; }
    //    public int ProductId { get; set; }
    //    public string ReviewText { get; set; }
    //}

    //public class TechEventSchema : Schema
    //{
    //    public TechEventSchema(IDependencyResolver resolver)
    //    {
    //        Query = resolver.Resolve<TechEventQuery>();
    //        DependencyResolver = resolver;
    //    }

    //}
    //public class HelloWorldQuery : ObjectGraphType
    //{
    //    public HelloWorldQuery()
    //    {


    //        Field<Product>("getProduct")
    //            .Arguments(new QueryArguments(new QueryArgument<IntGraphType> { Name = "id" }))
    //            .Resolve(context =>
    //            {
    //                var productId = context.GetArgument<int>("id");
    //                // Implement logic to fetch product by id from your data source
    //                return GetProductById(productId);
    //            });
    //        Field<ListGraphType<ProductReviewType>>("getAllReviews")
    //        .Arguments(new QueryArguments(new QueryArgument<IntGraphType> { Name = "productId" }))
    //        .Resolve(context =>
    //        {
    //            var productId = context.GetArgument<int>("productId");
    //            // Implement logic to fetch all reviews for a product from your data source
    //            return GetAllReviewsForProduct(productId);
    //        });

    //    }

    //    // Implement methods to fetch data from your data source
    //    private Product GetProductById(int productId)
    //    {
    //        return new Product() { Id = productId, Name = "DSD" };

    //    }

    //    private List<ProductReview> GetAllReviewsForProduct(int productId)
    //    {
    //        return new List<ProductReview>(){
    //            new ProductReview() { Id = 1, ProductId = productId , ReviewText = "DSD is good" },
    //        };

    //    }

    //}

    //public class ProductReviewType : ObjectGraphType<ProductReview>
    //{
    //    public ProductReviewType()
    //    {
    //        Field(x => x.Id).Description("Review id.");
    //        Field(x => x.ProductId).Description("Product Id.");
    //        Field(x => x.ReviewText).Description("Review Message.");
    //    }
    //}

}
